export interface Product {
  id: string;
  name: string;
  price: number;
  discountPrice?: number;
  category: string;
  subCategory?: string;
  image: string;
  images: string[];
  description: string;
  shortDescription: string;
  features: string[];
  inStock: boolean;
  isNew?: boolean;
  isFeatured?: boolean;
  rating: number;
  reviewCount: number;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Tensiomètre Digital",
    price: 59.99,
    category: "medical-equipment",
    subCategory: "diagnostic",
    image: "https://images.pexels.com/photos/8942991/pexels-photo-8942991.jpeg",
    images: [
      "https://images.pexels.com/photos/8942991/pexels-photo-8942991.jpeg",
      "https://images.pexels.com/photos/8943407/pexels-photo-8943407.jpeg",
      "https://images.pexels.com/photos/8943392/pexels-photo-8943392.jpeg"
    ],
    description: "Ce tensiomètre digital de haute précision permet une mesure facile et fiable de la tension artérielle. Doté d'un écran LCD facile à lire, il mémorise jusqu'à 60 mesures et détecte les arythmies cardiaques. L'appareil inclut un brassard confortable ajustable pour différentes tailles de bras et fonctionne avec des piles AAA (incluses). Idéal pour un suivi régulier à domicile, il est livré avec un étui de rangement et un guide d'utilisation complet.",
    shortDescription: "Tensiomètre automatique avec écran LCD et détection d'arythmie",
    features: [
      "Mesure précise de la tension systolique et diastolique",
      "Écran LCD facile à lire",
      "Mémoire pour 60 mesures",
      "Détection d'arythmie cardiaque",
      "Brassard confortable et ajustable"
    ],
    inStock: true,
    isNew: true,
    isFeatured: true,
    rating: 4.7,
    reviewCount: 128
  },
  {
    id: "2",
    name: "Déambulateur Pliable Léger",
    price: 89.99,
    discountPrice: 79.99,
    category: "mobility",
    subCategory: "walking-aids",
    image: "https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg",
    images: [
      "https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg",
      "https://images.pexels.com/photos/7089396/pexels-photo-7089396.jpeg",
      "https://images.pexels.com/photos/7089624/pexels-photo-7089624.jpeg"
    ],
    description: "Ce déambulateur pliable ultra-léger en aluminium anodisé est conçu pour offrir un soutien optimal tout en étant facile à transporter. Avec ses poignées ergonomiques ajustables en hauteur (de 78 à 98 cm), il s'adapte parfaitement à la morphologie de chacun. Les embouts antidérapants assurent une stabilité sur tous types de surfaces. Facilement pliable, il se range dans un minimum d'espace et ne pèse que 2,8 kg, ce qui le rend idéal pour les déplacements. Testé pour supporter jusqu'à 130 kg, il allie solidité et légèreté pour une assistance quotidienne fiable.",
    shortDescription: "Déambulateur en aluminium léger et pliable avec poignées ergonomiques",
    features: [
      "Structure en aluminium anodisé ultra-léger (2,8 kg)",
      "Poignées ergonomiques ajustables en hauteur",
      "Embouts antidérapants pour plus de sécurité",
      "Pliable pour un rangement facile",
      "Supporte jusqu'à 130 kg"
    ],
    inStock: true,
    isFeatured: true,
    rating: 4.5,
    reviewCount: 94
  },
  {
    id: "3",
    name: "Coussin Lombaire Ergonomique",
    price: 34.99,
    category: "orthopedic",
    subCategory: "back-support",
    image: "https://images.pexels.com/photos/5699514/pexels-photo-5699514.jpeg",
    images: [
      "https://images.pexels.com/photos/5699514/pexels-photo-5699514.jpeg",
      "https://images.pexels.com/photos/5699503/pexels-photo-5699503.jpeg",
      "https://images.pexels.com/photos/5699410/pexels-photo-5699410.jpeg"
    ],
    description: "Ce coussin lombaire ergonomique est spécialement conçu pour soulager les douleurs du bas du dos et maintenir une posture correcte. Fabriqué en mousse à mémoire de forme de haute densité, il offre un soutien optimal tout en s'adaptant parfaitement à la forme de votre dos. La housse en tissu respirant est amovible et lavable en machine. Sa sangle élastique ajustable permet de le fixer facilement à n'importe quelle chaise de bureau, siège de voiture ou fauteuil. Compact et léger, vous pouvez l'emporter partout pour un confort permanent.",
    shortDescription: "Coussin ergonomique en mousse à mémoire de forme pour le soutien lombaire",
    features: [
      "Mousse à mémoire de forme de haute densité",
      "Forme ergonomique adaptée à la courbe naturelle du dos",
      "Housse respirante et lavable en machine",
      "Sangle ajustable pour une fixation sécurisée",
      "Portable pour une utilisation au bureau ou en voiture"
    ],
    inStock: true,
    rating: 4.3,
    reviewCount: 76
  },
  {
    id: "4",
    name: "Attelle de Poignet Stabilisatrice",
    price: 24.99,
    category: "orthopedic",
    subCategory: "braces",
    image: "https://images.pexels.com/photos/5699467/pexels-photo-5699467.jpeg",
    images: [
      "https://images.pexels.com/photos/5699467/pexels-photo-5699467.jpeg",
      "https://images.pexels.com/photos/5699469/pexels-photo-5699469.jpeg",
      "https://images.pexels.com/photos/5699493/pexels-photo-5699493.jpeg"
    ],
    description: "Cette attelle de poignet stabilisatrice offre un maintien optimal pour les personnes souffrant d'entorses, de tendinites ou du syndrome du canal carpien. Sa conception avec éclisse palmaire en aluminium maintient le poignet dans une position neutre tout en permettant la mobilité des doigts. Les sangles ajustables assurent un serrage personnalisé pour un confort maximal. Fabriquée en néoprène respirant avec doublure en coton hypoallergénique, elle peut être portée jour et nuit. Ambidextre, elle s'adapte aussi bien au poignet droit qu'au gauche et est disponible en plusieurs tailles.",
    shortDescription: "Attelle stabilisatrice pour poignet avec éclisse palmaire et sangles ajustables",
    features: [
      "Éclisse palmaire en aluminium pour un maintien optimal",
      "Sangles ajustables pour un ajustement personnalisé",
      "Matériau néoprène respirant avec doublure en coton",
      "Conception permettant la mobilité des doigts",
      "Ambidextre - convient aux deux poignets"
    ],
    inStock: true,
    isNew: true,
    rating: 4.6,
    reviewCount: 52
  },
  {
    id: "5",
    name: "Oxymètre de Pouls Digital",
    price: 29.99,
    discountPrice: 24.99,
    category: "medical-equipment",
    subCategory: "diagnostic",
    image: "https://images.pexels.com/photos/8942997/pexels-photo-8942997.jpeg",
    images: [
      "https://images.pexels.com/photos/8942997/pexels-photo-8942997.jpeg",
      "https://images.pexels.com/photos/8943405/pexels-photo-8943405.jpeg",
      "https://images.pexels.com/photos/8943010/pexels-photo-8943010.jpeg"
    ],
    description: "Cet oxymètre de pouls digital permet de mesurer rapidement et précisément la saturation en oxygène du sang (SpO2) et la fréquence cardiaque. Son écran LED couleur OLED affiche clairement les résultats sous forme numérique et graphique. Compact et léger, il fonctionne avec 2 piles AAA (incluses) pour plus de 30 heures d'utilisation continue. Simple d'utilisation avec un seul bouton, il s'éteint automatiquement après 8 secondes d'inactivité pour économiser la batterie. Livré avec une dragonne et un étui de protection, il est idéal pour un usage domestique ou sportif.",
    shortDescription: "Oxymètre digital pour mesurer la saturation en oxygène et le pouls",
    features: [
      "Mesure précise de la SpO2 et de la fréquence cardiaque",
      "Écran LED OLED multicolore facile à lire",
      "Compact et léger - idéal pour une utilisation quotidienne",
      "Économie d'énergie avec arrêt automatique",
      "Livré avec dragonne et étui de protection"
    ],
    inStock: true,
    isFeatured: true,
    rating: 4.8,
    reviewCount: 203
  },
  {
    id: "6",
    name: "Bande de Kinésiologie",
    price: 12.99,
    category: "orthopedic",
    subCategory: "tapes",
    image: "https://images.pexels.com/photos/4506108/pexels-photo-4506108.jpeg",
    images: [
      "https://images.pexels.com/photos/4506108/pexels-photo-4506108.jpeg",
      "https://images.pexels.com/photos/4506166/pexels-photo-4506166.jpeg",
      "https://images.pexels.com/photos/4506207/pexels-photo-4506207.jpeg"
    ],
    description: "Cette bande de kinésiologie professionnelle est conçue pour soutenir les muscles et faciliter leur récupération sans limiter l'amplitude des mouvements. Fabriquée en coton élastique de haute qualité avec une adhésive acrylique hypoallergénique, elle reste en place jusqu'à 5 jours, même sous la douche. Son élasticité de 130-140% imite celle de la peau humaine pour un confort optimal. Résistante à l'eau et respirante, elle permet une utilisation prolongée sans irritation. Chaque rouleau mesure 5m x 5cm et est disponible en plusieurs coloris. Idéale pour les sportifs ou pour soulager les douleurs musculaires quotidiennes.",
    shortDescription: "Bande élastique adhésive pour le soutien musculaire et la récupération",
    features: [
      "Coton élastique de haute qualité avec adhésif hypoallergénique",
      "Élasticité de 130-140% comparable à celle de la peau",
      "Résistante à l'eau - reste en place jusqu'à 5 jours",
      "Respirante pour un confort prolongé",
      "Rouleau de 5m x 5cm"
    ],
    inStock: true,
    rating: 4.4,
    reviewCount: 89
  },
  {
    id: "7",
    name: "Fauteuil Roulant Pliable",
    price: 299.99,
    discountPrice: 279.99,
    category: "mobility",
    subCategory: "wheelchairs",
    image: "https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg",
    images: [
      "https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg",
      "https://images.pexels.com/photos/3845808/pexels-photo-3845808.jpeg",
      "https://images.pexels.com/photos/3845809/pexels-photo-3845809.jpeg"
    ],
    description: "Ce fauteuil roulant pliable allie robustesse et praticité pour une utilisation quotidienne confortable. Sa structure en aluminium renforcé offre légèreté (seulement 12,5 kg) et solidité, supportant jusqu'à 120 kg. Les accoudoirs rembourrés et relevables facilitent les transferts, tandis que les repose-pieds sont réglables et escamotables. Son siège de 45 cm de largeur en nylon rembourrée est imperméable et facile à nettoyer. Équipé de roues arrière de 24 pouces avec mains courantes ergonomiques et de roues avant de 8 pouces, il assure une maniabilité optimale. Un système de freinage efficace complète cet équipement qui se plie facilement pour le transport ou le rangement.",
    shortDescription: "Fauteuil roulant léger en aluminium avec accoudoirs relevables et repose-pieds réglables",
    features: [
      "Structure légère en aluminium (12,5 kg) supporte jusqu'à 120 kg",
      "Accoudoirs rembourrés et relevables pour faciliter les transferts",
      "Repose-pieds réglables et escamotables",
      "Siège de 45 cm en nylon imperméable et facile à nettoyer",
      "Pliable pour un transport et un rangement facile"
    ],
    inStock: true,
    rating: 4.7,
    reviewCount: 42
  },
  {
    id: "8",
    name: "Kit de Premiers Secours Familial",
    price: 45.99,
    category: "medical-equipment",
    subCategory: "first-aid",
    image: "https://images.pexels.com/photos/9090757/pexels-photo-9090757.jpeg",
    images: [
      "https://images.pexels.com/photos/9090757/pexels-photo-9090757.jpeg",
      "https://images.pexels.com/photos/9090784/pexels-photo-9090784.jpeg",
      "https://images.pexels.com/photos/9090732/pexels-photo-9090732.jpeg"
    ],
    description: "Ce kit complet de premiers secours contient 156 articles essentiels pour faire face aux urgences quotidiennes. Il comprend des pansements de différentes tailles, des compresses stériles, des bandes élastiques, des lingettes antiseptiques, des gants, un masque de réanimation, une couverture de survie, des ciseaux médicaux et bien plus. Le tout est rangé dans une trousse robuste en nylon avec poignée de transport et fermeture éclair de qualité. Compact mais complet, il est idéal pour la maison, la voiture ou les activités de plein air. Un guide de premiers secours illustré est inclus pour vous aider à réagir efficacement en situation d'urgence.",
    shortDescription: "Kit complet de 156 articles pour les urgences quotidiennes",
    features: [
      "156 articles médicaux essentiels",
      "Trousse robuste en nylon avec poignée de transport",
      "Comprend pansements, compresses, bandes, antiseptiques et plus",
      "Guide illustré de premiers secours inclus",
      "Compact et portable - idéal pour la maison ou les déplacements"
    ],
    inStock: true,
    isNew: true,
    isFeatured: true,
    rating: 4.9,
    reviewCount: 156
  },
  {
    id: "9",
    name: "Bas de Contention Classe 2",
    price: 29.99,
    category: "hygiene",
    subCategory: "compression",
    image: "https://images.pexels.com/photos/3785693/pexels-photo-3785693.jpeg",
    images: [
      "https://images.pexels.com/photos/3785693/pexels-photo-3785693.jpeg",
      "https://images.pexels.com/photos/3785691/pexels-photo-3785691.jpeg",
      "https://images.pexels.com/photos/3760845/pexels-photo-3760845.jpeg"
    ],
    description: "Ces bas de contention classe 2 (pression 15-20 mmHg) offrent un soulagement efficace pour les personnes souffrant de jambes lourdes, de varices ou à risque de thrombose. Fabriqués en microfibre respirante de haute qualité, ils assurent un confort optimal même lors d'un port prolongé. Leur conception anatomique avec talon renforcé garantit une répartition uniforme de la pression et une durabilité exceptionnelle. La pointe et la bande supérieure élastiques évitent toute compression excessive. Disponibles en plusieurs tailles et coloris, ils se lavent en machine à 30°C et conservent leurs propriétés compressives après de multiples lavages.",
    shortDescription: "Bas de contention médicale classe 2 (15-20 mmHg) en microfibre respirante",
    features: [
      "Pression graduelle 15-20 mmHg (classe 2)",
      "Microfibre respirante pour un confort quotidien",
      "Conception anatomique avec talon renforcé",
      "Bande supérieure élastique non constrictive",
      "Résistants et durables - lavables en machine"
    ],
    inStock: true,
    rating: 4.5,
    reviewCount: 68
  },
  {
    id: "10",
    name: "Siège de Bain Pivotant",
    price: 119.99,
    discountPrice: 99.99,
    category: "hygiene",
    subCategory: "bathroom",
    image: "https://images.pexels.com/photos/7262405/pexels-photo-7262405.jpeg",
    images: [
      "https://images.pexels.com/photos/7262405/pexels-photo-7262405.jpeg",
      "https://images.pexels.com/photos/7262400/pexels-photo-7262400.jpeg",
      "https://images.pexels.com/photos/7262399/pexels-photo-7262399.jpeg"
    ],
    description: "Ce siège de bain pivotant à 360° facilite l'accès à la baignoire pour les personnes à mobilité réduite ou âgées. Sa structure en aluminium anticorrosion supporte jusqu'à 130 kg et se fixe solidement sur tous types de baignoires grâce à ses pinces ajustables. L'assise ergonomique en plastique moulé (40 x 40 cm) est dotée d'ouvertures pour l'écoulement de l'eau et de poignées latérales sécurisantes. Le dossier amovible apporte un confort supplémentaire. Le système de verrouillage tous les 90° sécurise les transferts. Sans outils nécessaires pour l'installation, il s'adapte aux baignoires de 40 à 65 cm de largeur intérieure.",
    shortDescription: "Siège de bain pivotant à 360° pour personnes à mobilité réduite",
    features: [
      "Rotation à 360° avec verrouillage tous les 90°",
      "Structure en aluminium supportant jusqu'à 130 kg",
      "Assise ergonomique (40x40 cm) avec poignées latérales",
      "Dossier amovible pour plus de confort",
      "Installation facile sans outils sur baignoires de 40-65 cm"
    ],
    inStock: true,
    isFeatured: true,
    rating: 4.6,
    reviewCount: 37
  },
  {
    id: "11",
    name: "Appareil d'Électrothérapie TENS",
    price: 69.99,
    category: "medical-equipment",
    subCategory: "therapy",
    image: "https://images.pexels.com/photos/8943160/pexels-photo-8943160.jpeg",
    images: [
      "https://images.pexels.com/photos/8943160/pexels-photo-8943160.jpeg",
      "https://images.pexels.com/photos/8943170/pexels-photo-8943170.jpeg",
      "https://images.pexels.com/photos/8943150/pexels-photo-8943150.jpeg"
    ],
    description: "Cet appareil d'électrothérapie TENS (Transcutaneous Electrical Nerve Stimulation) soulage naturellement les douleurs chroniques et aiguës sans médicaments. Avec ses 16 programmes préréglés et 8 modes personnalisables, il s'adapte à diverses situations : douleurs musculaires, articulaires, cervicales, lombaires ou neuropathiques. L'intensité est réglable sur 20 niveaux pour un confort optimal. Ses 4 canaux indépendants permettent de traiter plusieurs zones simultanément avec les 8 électrodes fournies. L'écran LCD rétroéclairé assure une utilisation facile, même dans l'obscurité. Compact et rechargeable via USB, il offre jusqu'à 10 heures d'autonomie. Livré avec électrodes, câbles, manuel détaillé et étui de rangement.",
    shortDescription: "Appareil TENS digital avec 16 programmes pour soulager les douleurs sans médicaments",
    features: [
      "16 programmes préréglés et 8 modes personnalisables",
      "4 canaux indépendants pour traiter plusieurs zones",
      "Intensité réglable sur 20 niveaux",
      "Batterie rechargeable USB avec 10 heures d'autonomie",
      "Livré complet avec 8 électrodes et accessoires"
    ],
    inStock: true,
    isNew: true,
    rating: 4.7,
    reviewCount: 104
  },
  {
    id: "12",
    name: "Solution Hydroalcoolique 500ml",
    price: 9.99,
    category: "hygiene",
    subCategory: "sanitizers",
    image: "https://images.pexels.com/photos/6098232/pexels-photo-6098232.jpeg",
    images: [
      "https://images.pexels.com/photos/6098232/pexels-photo-6098232.jpeg",
      "https://images.pexels.com/photos/6098229/pexels-photo-6098229.jpeg",
      "https://images.pexels.com/photos/6098235/pexels-photo-6098235.jpeg"
    ],
    description: "Cette solution hydroalcoolique médicale contient 70% d'alcool pour une désinfection efficace des mains. Sa formule enrichie en glycérine et aloe vera protège l'épiderme contre le dessèchement, même en cas d'utilisations fréquentes. Le flacon pompe de 500ml permet un dosage précis et économique. Sans parfum, sans colorant et hypoallergénique, elle convient aux peaux sensibles et aux environnements médicaux. Elle élimine 99,9% des bactéries, virus et champignons en 30 secondes. Son format pratique la rend idéale pour la maison, le bureau ou les déplacements. Conforme aux normes européennes EN 1500, EN 14476 et EN 12791.",
    shortDescription: "Solution désinfectante avec 70% d'alcool, enrichie en glycérine et aloe vera",
    features: [
      "70% d'alcool - conforme aux normes médicales",
      "Enrichie en glycérine et aloe vera pour protéger la peau",
      "Élimine 99,9% des germes en 30 secondes",
      "Flacon pompe pratique de 500ml",
      "Sans parfum, sans colorant et hypoallergénique"
    ],
    inStock: true,
    rating: 4.8,
    reviewCount: 215
  }
];

export const categories = [
  {
    id: "medical-equipment",
    name: "Équipement Médical",
    description: "Appareils et outils pour le diagnostic et le suivi médical",
    image: "https://images.pexels.com/photos/4386466/pexels-photo-4386466.jpeg"
  },
  {
    id: "mobility",
    name: "Mobilité",
    description: "Solutions d'aide à la mobilité pour personnes à capacité réduite",
    image: "https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg"
  },
  {
    id: "orthopedic",
    name: "Orthopédie",
    description: "Produits de soutien et correction orthopédique",
    image: "https://images.pexels.com/photos/4506108/pexels-photo-4506108.jpeg"
  },
  {
    id: "hygiene",
    name: "Hygiène et Soins",
    description: "Produits pour l'hygiène personnelle et les soins quotidiens",
    image: "https://images.pexels.com/photos/6098232/pexels-photo-6098232.jpeg"
  }
];

export const featuredProducts = products.filter(product => product.isFeatured);
export const newProducts = products.filter(product => product.isNew);
export const getProductsByCategory = (categoryId: string) => products.filter(product => product.category === categoryId);
export const getProductById = (id: string) => products.find(product => product.id === id);