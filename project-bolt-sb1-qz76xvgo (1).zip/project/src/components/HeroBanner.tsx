import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const HeroBanner = () => {
  return (
    <section className="relative bg-gradient-to-r from-blue-600 to-teal-500 text-white overflow-hidden">
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Votre santé mérite le meilleur équipement
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-8">
            Découvrez notre gamme complète de produits paramédicaux de haute qualité à des prix accessibles.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link 
              to="/products" 
              className="bg-white text-blue-600 px-6 py-3 rounded-md font-medium flex items-center justify-center gap-2 hover:bg-gray-100 transition-colors"
            >
              Voir nos produits
              <ArrowRight size={18} />
            </Link>
            <Link 
              to="/services" 
              className="bg-transparent border border-white text-white px-6 py-3 rounded-md font-medium flex items-center justify-center hover:bg-white/10 transition-colors"
            >
              Nos services
            </Link>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-full h-full overflow-hidden opacity-10">
        <div className="absolute top-0 left-0 w-40 h-40 lg:w-64 lg:h-64 rounded-full bg-white transform translate-x-20 -translate-y-20"></div>
        <div className="absolute bottom-0 right-0 w-80 h-80 lg:w-96 lg:h-96 rounded-full bg-white transform translate-x-1/3 translate-y-1/3"></div>
      </div>
    </section>
  );
};

export default HeroBanner;