import { Link } from 'react-router-dom';
import { ShoppingCart, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  featured?: boolean;
}

const ProductCard = ({ product, featured = false }: ProductCardProps) => {
  const { addToCart } = useCart();
  const { id, name, price, discountPrice, image, rating, reviewCount, isNew } = product;
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  return (
    <div className={`group relative rounded-lg overflow-hidden bg-white shadow-md transition-all duration-300 hover:shadow-lg ${featured ? 'lg:flex lg:items-center' : ''}`}>
      {isNew && (
        <div className="absolute top-2 left-2 z-10 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded">
          Nouveau
        </div>
      )}
      
      {discountPrice && (
        <div className="absolute top-2 right-2 z-10 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
          -{Math.round(((price - discountPrice) / price) * 100)}%
        </div>
      )}
      
      <Link to={`/products/${id}`} className={`block ${featured ? 'lg:flex lg:gap-6' : ''}`}>
        <div className={`overflow-hidden ${featured ? 'lg:w-1/2' : 'h-48'}`}>
          <img 
            src={image} 
            alt={name} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
        
        <div className={`p-4 ${featured ? 'lg:w-1/2' : ''}`}>
          <h3 className="text-gray-800 font-semibold text-lg mb-2 line-clamp-2">{name}</h3>
          
          <div className="flex items-center mb-2">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <svg 
                  key={i}
                  className={`w-4 h-4 ${i < Math.floor(rating) ? 'fill-current' : 'stroke-current fill-none'}`}
                  viewBox="0 0 24 24"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth="2" 
                    d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                  />
                </svg>
              ))}
              <span className="text-xs text-gray-500 ml-1">({reviewCount})</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div>
              {discountPrice ? (
                <div className="flex items-center">
                  <span className="text-gray-500 line-through text-sm mr-2">{price.toFixed(2)}€</span>
                  <span className="text-red-600 font-bold">{discountPrice.toFixed(2)}€</span>
                </div>
              ) : (
                <span className="font-bold text-gray-800">{price.toFixed(2)}€</span>
              )}
            </div>
            
            <div className="flex space-x-2">
              <button 
                className="p-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
                aria-label="Ajouter aux favoris"
              >
                <Heart size={18} />
              </button>
              <button 
                onClick={handleAddToCart}
                className="p-2 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                aria-label="Ajouter au panier"
              >
                <ShoppingCart size={18} />
              </button>
            </div>
          </div>
          
          {featured && (
            <p className="text-gray-600 text-sm mt-3 line-clamp-3">{product.shortDescription}</p>
          )}
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;