import { useEffect } from 'react';
import { Clock, User, Ruler, Car, PenTool as Tool, Activity } from 'lucide-react';

const ServicesPage = () => {
  useEffect(() => {
    // Update page title
    document.title = 'Nos Services - MédiPara';
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-16 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Des services adaptés à vos besoins
            </h1>
            <p className="text-lg md:text-xl opacity-90">
              Découvrez notre gamme complète de services paramédicaux personnalisés pour vous accompagner au quotidien.
            </p>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-full h-full overflow-hidden opacity-10">
          <div className="absolute top-0 left-0 w-40 h-40 lg:w-64 lg:h-64 rounded-full bg-white transform translate-x-20 -translate-y-20"></div>
          <div className="absolute bottom-0 right-0 w-80 h-80 lg:w-96 lg:h-96 rounded-full bg-white transform translate-x-1/3 translate-y-1/3"></div>
        </div>
      </section>
      
      {/* Services Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-800 text-center mb-12">
            Nos Services Professionnels
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Ruler className="text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Conseil et adaptation</h3>
              <p className="text-gray-600 mb-4">
                Nos spécialistes vous conseillent dans le choix des produits adaptés à vos besoins et à votre morphologie.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Évaluation personnalisée
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Conseils d'experts
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Essais avant achat
                </li>
              </ul>
            </div>
            
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <User className="text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Service à domicile</h3>
              <p className="text-gray-600 mb-4">
                Nos professionnels se déplacent chez vous pour l'installation et la prise en main de votre matériel médical.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Installation professionnelle
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Formation à l'utilisation
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Suivi personnalisé
                </li>
              </ul>
            </div>
            
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Car className="text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Livraison express</h3>
              <p className="text-gray-600 mb-4">
                Bénéficiez d'une livraison rapide de vos produits paramédicaux, y compris pour les articles volumineux.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Livraison en 24-48h
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Suivi de commande en temps réel
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Manipulation soignée
                </li>
              </ul>
            </div>
            
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Tool className="text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Location de matériel</h3>
              <p className="text-gray-600 mb-4">
                Louez du matériel médical de qualité pour vos besoins temporaires ou à long terme.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Matériel récent et entretenu
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Formules flexibles
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Service de maintenance inclus
                </li>
              </ul>
            </div>
            
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Activity className="text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Suivi médical</h3>
              <p className="text-gray-600 mb-4">
                Un suivi régulier par nos professionnels de santé pour ajuster votre équipement selon l'évolution de votre état.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Consultations régulières
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Ajustements personnalisés
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Conseils d'utilisation adaptés
                </li>
              </ul>
            </div>
            
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Clock className="text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Service après-vente</h3>
              <p className="text-gray-600 mb-4">
                Notre équipe technique assure l'entretien, la réparation et le SAV de tous vos équipements.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Réparations rapides
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Maintenance préventive
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  Garantie prolongée
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Pricing Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-800 text-center mb-12">
            Nos Tarifs
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Consultation de base</h3>
                <p className="text-gray-600 mb-6">Pour un conseil simple et rapide</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-800">Gratuit</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Conseil téléphonique
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Assistance produit
                  </li>
                  <li className="flex items-start text-gray-400">
                    <svg className="w-5 h-5 text-gray-300 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    Évaluation personnalisée
                  </li>
                  <li className="flex items-start text-gray-400">
                    <svg className="w-5 h-5 text-gray-300 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    Visite à domicile
                  </li>
                </ul>
                <button className="w-full py-3 px-4 border border-blue-600 text-blue-600 rounded-md font-medium hover:bg-blue-50 transition-colors">
                  Réserver
                </button>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm overflow-hidden border-2 border-blue-600 relative">
              <div className="absolute top-0 left-0 right-0 bg-blue-600 text-white text-sm font-semibold text-center py-1">
                Recommandé
              </div>
              <div className="p-6 pt-10">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Service complet</h3>
                <p className="text-gray-600 mb-6">Évaluation complète et personnalisée</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-800">49€</span>
                  <span className="text-gray-500 ml-1">/ visite</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Conseil téléphonique illimité
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Assistance produit
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Évaluation personnalisée
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Visite à domicile
                  </li>
                </ul>
                <button className="w-full py-3 px-4 bg-blue-600 text-white rounded-md font-medium hover:bg-blue-700 transition-colors">
                  Réserver
                </button>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Suivi régulier</h3>
                <p className="text-gray-600 mb-6">Suivi médical et technique complet</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-800">199€</span>
                  <span className="text-gray-500 ml-1">/ an</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Tous les services du forfait complet
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    4 visites annuelles
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Maintenance préventive
                  </li>
                  <li className="flex items-start">
                    <svg className="w-5 h-5 text-green-500 mr-2 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Remise de 10% sur les produits
                  </li>
                </ul>
                <button className="w-full py-3 px-4 border border-blue-600 text-blue-600 rounded-md font-medium hover:bg-blue-50 transition-colors">
                  Réserver
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-800 text-center mb-12">
            Questions fréquentes
          </h2>
          
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <details className="group">
                <summary className="flex items-center justify-between p-6 cursor-pointer">
                  <h3 className="text-lg font-medium text-gray-800">Comment prendre rendez-vous pour une consultation ?</h3>
                  <span className="ml-2 flex-shrink-0 text-gray-400 group-open:rotate-180 transition-transform">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 text-gray-600">
                  <p>
                    Vous pouvez prendre rendez-vous pour une consultation de plusieurs façons :
                  </p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Par téléphone au 01 23 45 67 89</li>
                    <li>Via notre formulaire de contact sur le site</li>
                    <li>En vous rendant directement en magasin</li>
                  </ul>
                  <p className="mt-2">
                    Nous vous proposerons un créneau dans les 48h suivant votre demande.
                  </p>
                </div>
              </details>
            </div>
            
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <details className="group">
                <summary className="flex items-center justify-between p-6 cursor-pointer">
                  <h3 className="text-lg font-medium text-gray-800">Les consultations à domicile sont-elles remboursées ?</h3>
                  <span className="ml-2 flex-shrink-0 text-gray-400 group-open:rotate-180 transition-transform">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 text-gray-600">
                  <p>
                    Selon votre situation et votre couverture médicale, certaines consultations peuvent être partiellement ou totalement remboursées :
                  </p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Les consultations sur prescription médicale sont prises en charge par l'Assurance Maladie</li>
                    <li>De nombreuses mutuelles remboursent également ces services</li>
                    <li>Pour les personnes en situation de handicap, des aides spécifiques existent (MDPH, PCH)</li>
                  </ul>
                  <p className="mt-2">
                    Nous vous fournissons toutes les factures détaillées nécessaires pour vos demandes de remboursement.
                  </p>
                </div>
              </details>
            </div>
            
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <details className="group">
                <summary className="flex items-center justify-between p-6 cursor-pointer">
                  <h3 className="text-lg font-medium text-gray-800">En quoi consiste le service de location de matériel ?</h3>
                  <span className="ml-2 flex-shrink-0 text-gray-400 group-open:rotate-180 transition-transform">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 text-gray-600">
                  <p>
                    Notre service de location vous permet d'accéder à du matériel médical de qualité sans avoir à l'acheter :
                  </p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Location courte durée (à partir d'une journée) ou longue durée (plusieurs mois)</li>
                    <li>Large gamme d'équipements disponibles : lits médicalisés, fauteuils roulants, déambulateurs, etc.</li>
                    <li>Matériel récent, entretenu et désinfecté entre chaque utilisation</li>
                    <li>Livraison, installation et reprise incluses</li>
                    <li>Tarifs dégressifs pour les locations longue durée</li>
                  </ul>
                  <p className="mt-2">
                    Idéal pour les besoins temporaires ou pour tester un équipement avant achat.
                  </p>
                </div>
              </details>
            </div>
            
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <details className="group">
                <summary className="flex items-center justify-between p-6 cursor-pointer">
                  <h3 className="text-lg font-medium text-gray-800">Quelle est la durée de garantie sur vos produits ?</h3>
                  <span className="ml-2 flex-shrink-0 text-gray-400 group-open:rotate-180 transition-transform">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 text-gray-600">
                  <p>
                    Tous nos produits bénéficient d'une garantie, qui varie selon le type d'équipement :
                  </p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Petit matériel médical : garantie standard de 2 ans</li>
                    <li>Équipement électrique/électronique : garantie de 2 à 5 ans selon les produits</li>
                    <li>Fauteuils roulants et mobilité : garantie de 3 ans sur le châssis, 1 an sur les pièces d'usure</li>
                    <li>Lits médicalisés : garantie de 5 ans sur la structure, 2 ans sur les moteurs</li>
                  </ul>
                  <p className="mt-2">
                    Nous proposons également des extensions de garantie pour une tranquillité maximale.
                  </p>
                </div>
              </details>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Prêt à bénéficier de nos services ?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Contactez-nous dès aujourd'hui pour prendre rendez-vous ou obtenir plus d'informations sur nos services personnalisés.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+33123456789" 
              className="inline-block bg-white text-blue-600 px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
            >
              Appelez-nous
            </a>
            <a 
              href="/contact" 
              className="inline-block bg-transparent border border-white text-white px-6 py-3 rounded-md font-medium hover:bg-white/10 transition-colors"
            >
              Formulaire de contact
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;