import { Link } from 'react-router-dom';

interface CategoryCardProps {
  id: string;
  name: string;
  description: string;
  image: string;
}

const CategoryCard = ({ id, name, description, image }: CategoryCardProps) => {
  return (
    <Link 
      to={`/products?category=${id}`}
      className="block relative rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-lg group"
    >
      <div className="aspect-w-4 aspect-h-3">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
        <h3 className="text-xl font-semibold mb-1">{name}</h3>
        <p className="text-sm text-gray-200">{description}</p>
      </div>
    </Link>
  );
};

export default CategoryCard;