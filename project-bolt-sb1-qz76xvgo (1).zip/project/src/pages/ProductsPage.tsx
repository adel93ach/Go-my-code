import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, X } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products, categories } from '../data/products';

const ProductsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [sortOption, setSortOption] = useState('newest');
  const [priceRange, setPriceRange] = useState({ min: 0, max: 300 });
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  useEffect(() => {
    // Update page title
    document.title = 'Produits - MédiPara';
    
    // Get category from URL params
    const categoryParam = searchParams.get('category');
    if (categoryParam) {
      setActiveCategory(categoryParam);
    }
  }, [searchParams]);

  useEffect(() => {
    // Filter products based on active filters
    let filtered = [...products];
    
    // Apply category filter
    if (activeCategory) {
      filtered = filtered.filter(product => product.category === activeCategory);
    }
    
    // Apply price range filter
    filtered = filtered.filter(product => {
      const price = product.discountPrice || product.price;
      return price >= priceRange.min && price <= priceRange.max;
    });
    
    // Apply sorting
    switch (sortOption) {
      case 'price-asc':
        filtered.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
        break;
      case 'price-desc':
        filtered.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
      default:
        // Assuming newer products have higher IDs for this demo
        filtered.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        break;
    }
    
    setFilteredProducts(filtered);
  }, [activeCategory, sortOption, priceRange]);

  const handleCategoryChange = (categoryId: string | null) => {
    setActiveCategory(categoryId);
    
    if (categoryId) {
      searchParams.set('category', categoryId);
    } else {
      searchParams.delete('category');
    }
    
    setSearchParams(searchParams);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortOption(e.target.value);
  };

  const handlePriceRangeChange = (type: 'min' | 'max', value: number) => {
    setPriceRange(prev => ({
      ...prev,
      [type]: value
    }));
  };

  const handleClearFilters = () => {
    setActiveCategory(null);
    setSortOption('newest');
    setPriceRange({ min: 0, max: 300 });
    setSearchParams({});
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Nos Produits</h1>
        
        {/* Mobile Filter Toggle */}
        <div className="md:hidden mb-4">
          <button
            onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
            className="flex items-center justify-center w-full p-3 bg-white border border-gray-300 rounded-md text-gray-700"
          >
            <Filter size={18} className="mr-2" />
            Filtres et tri
          </button>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters Sidebar - Mobile */}
          {isMobileFilterOpen && (
            <div className="fixed inset-0 z-50 bg-gray-800 bg-opacity-75 md:hidden">
              <div className="absolute inset-y-0 right-0 max-w-md w-full bg-white shadow-xl flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b">
                  <h2 className="text-lg font-semibold">Filtres</h2>
                  <button 
                    onClick={() => setIsMobileFilterOpen(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X size={24} />
                  </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4">
                  <div className="mb-6">
                    <h3 className="text-sm font-semibold uppercase text-gray-500 mb-3">Catégories</h3>
                    <div className="space-y-2">
                      <button
                        onClick={() => handleCategoryChange(null)}
                        className={`block w-full text-left px-3 py-2 rounded-md ${
                          activeCategory === null 
                            ? 'bg-blue-100 text-blue-600' 
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        Toutes les catégories
                      </button>
                      {categories.map(category => (
                        <button
                          key={category.id}
                          onClick={() => handleCategoryChange(category.id)}
                          className={`block w-full text-left px-3 py-2 rounded-md ${
                            activeCategory === category.id 
                              ? 'bg-blue-100 text-blue-600' 
                              : 'text-gray-700 hover:bg-gray-100'
                          }`}
                        >
                          {category.name}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-sm font-semibold uppercase text-gray-500 mb-3">Prix</h3>
                    <div className="px-3">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-600">{priceRange.min}€</span>
                        <span className="text-sm text-gray-600">{priceRange.max}€</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="300"
                        value={priceRange.max}
                        onChange={(e) => handlePriceRangeChange('max', parseInt(e.target.value))}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-sm font-semibold uppercase text-gray-500 mb-3">Tri</h3>
                    <div className="px-3">
                      <select
                        value={sortOption}
                        onChange={handleSortChange}
                        className="w-full p-2 border border-gray-300 rounded-md bg-white"
                      >
                        <option value="newest">Plus récents</option>
                        <option value="price-asc">Prix croissant</option>
                        <option value="price-desc">Prix décroissant</option>
                        <option value="rating">Meilleures notes</option>
                      </select>
                    </div>
                  </div>
                  
                  <button
                    onClick={handleClearFilters}
                    className="w-full p-3 text-center text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-md"
                  >
                    Effacer les filtres
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Filters Sidebar - Desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="mb-6">
                <h3 className="text-sm font-semibold uppercase text-gray-500 mb-3">Catégories</h3>
                <div className="space-y-2">
                  <button
                    onClick={() => handleCategoryChange(null)}
                    className={`block w-full text-left px-3 py-2 rounded-md ${
                      activeCategory === null 
                        ? 'bg-blue-100 text-blue-600' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Toutes les catégories
                  </button>
                  {categories.map(category => (
                    <button
                      key={category.id}
                      onClick={() => handleCategoryChange(category.id)}
                      className={`block w-full text-left px-3 py-2 rounded-md ${
                        activeCategory === category.id 
                          ? 'bg-blue-100 text-blue-600' 
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {category.name}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-semibold uppercase text-gray-500 mb-3">Prix</h3>
                <div className="px-3">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">{priceRange.min}€</span>
                    <span className="text-sm text-gray-600">{priceRange.max}€</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="300"
                    value={priceRange.max}
                    onChange={(e) => handlePriceRangeChange('max', parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>
              </div>
              
              <button
                onClick={handleClearFilters}
                className="w-full p-3 text-center text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-md"
              >
                Effacer les filtres
              </button>
            </div>
          </div>
          
          {/* Products Grid */}
          <div className="flex-1">
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
              <div className="text-gray-600 mb-3 sm:mb-0">
                Affichage de <span className="font-semibold">{filteredProducts.length}</span> produits
              </div>
              
              <select
                value={sortOption}
                onChange={handleSortChange}
                className="p-2 border border-gray-300 rounded-md bg-white sm:w-auto w-full"
              >
                <option value="newest">Plus récents</option>
                <option value="price-asc">Prix croissant</option>
                <option value="price-desc">Prix décroissant</option>
                <option value="rating">Meilleures notes</option>
              </select>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            
            {filteredProducts.length === 0 && (
              <div className="bg-white p-8 rounded-lg shadow-sm text-center">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Aucun produit trouvé</h3>
                <p className="text-gray-600">
                  Essayez de modifier vos filtres ou explorez d'autres catégories.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;