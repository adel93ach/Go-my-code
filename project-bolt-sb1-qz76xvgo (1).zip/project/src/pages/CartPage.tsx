import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ArrowRight, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import QuantitySelector from '../components/QuantitySelector';

const CartPage = () => {
  useEffect(() => {
    // Update page title
    document.title = 'Panier - MédiPara';
  }, []);

  const { cartItems, removeFromCart, updateQuantity, cartTotal } = useCart();
  
  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Votre Panier</h1>
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="text-gray-500" size={24} />
          </div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Votre panier est vide</h2>
          <p className="text-gray-600 mb-6">
            Vous n'avez aucun article dans votre panier. Découvrez nos produits et commencez vos achats.
          </p>
          <Link 
            to="/products" 
            className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-700 transition-colors"
          >
            Parcourir les produits
          </Link>
        </div>
      </div>
    );
  }

  const handleIncreaseQuantity = (id: string, currentQuantity: number) => {
    updateQuantity(id, currentQuantity + 1);
  };

  const handleDecreaseQuantity = (id: string, currentQuantity: number) => {
    if (currentQuantity > 1) {
      updateQuantity(id, currentQuantity - 1);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Votre Panier</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="hidden sm:grid grid-cols-12 gap-4 p-4 bg-gray-50 text-gray-600 font-medium">
              <div className="col-span-6">Produit</div>
              <div className="col-span-2 text-center">Prix</div>
              <div className="col-span-2 text-center">Quantité</div>
              <div className="col-span-2 text-center">Total</div>
            </div>
            
            <div className="divide-y divide-gray-200">
              {cartItems.map(item => (
                <div key={item.id} className="p-4 sm:p-6 grid sm:grid-cols-12 gap-4 items-center">
                  <div className="sm:col-span-6 flex items-center">
                    <div className="w-20 h-20 flex-shrink-0">
                      <img 
                        src={item.image} 
                        alt={item.name} 
                        className="w-full h-full object-cover rounded-md"
                      />
                    </div>
                    <div className="ml-4">
                      <Link 
                        to={`/products/${item.id}`} 
                        className="text-lg font-medium text-gray-800 hover:text-blue-600 transition-colors"
                      >
                        {item.name}
                      </Link>
                    </div>
                  </div>
                  
                  <div className="sm:col-span-2 text-center">
                    <div className="sm:hidden text-gray-500 text-sm mb-1">Prix:</div>
                    {item.discountPrice ? (
                      <div className="flex items-center sm:justify-center">
                        <span className="text-gray-500 line-through text-sm mr-2">{item.price.toFixed(2)}€</span>
                        <span className="font-medium">{item.discountPrice.toFixed(2)}€</span>
                      </div>
                    ) : (
                      <span className="font-medium">{item.price.toFixed(2)}€</span>
                    )}
                  </div>
                  
                  <div className="sm:col-span-2 flex justify-center">
                    <div className="sm:hidden text-gray-500 text-sm mb-1">Quantité:</div>
                    <QuantitySelector
                      quantity={item.quantity}
                      onIncrease={() => handleIncreaseQuantity(item.id, item.quantity)}
                      onDecrease={() => handleDecreaseQuantity(item.id, item.quantity)}
                    />
                  </div>
                  
                  <div className="sm:col-span-2 text-center flex justify-between sm:block">
                    <div className="sm:hidden text-gray-500 text-sm">Total:</div>
                    <span className="font-medium">
                      {((item.discountPrice || item.price) * item.quantity).toFixed(2)}€
                    </span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-red-500 hover:text-red-700 transition-colors sm:mt-2"
                      aria-label="Supprimer l'article"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-6">
            <Link 
              to="/products" 
              className="text-blue-600 font-medium hover:text-blue-800 transition-colors flex items-center"
            >
              <ArrowRight size={16} className="mr-2 transform rotate-180" />
              Continuer vos achats
            </Link>
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Récapitulatif</h2>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>Sous-total</span>
                <span>{cartTotal.toFixed(2)}€</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Livraison</span>
                <span>Calculé à l'étape suivante</span>
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-4 mb-6">
              <div className="flex justify-between text-lg font-semibold">
                <span>Total</span>
                <span>{cartTotal.toFixed(2)}€</span>
              </div>
              <p className="text-gray-500 text-sm mt-1">TVA incluse</p>
            </div>
            
            <Link
              to="/checkout"
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-md font-medium flex items-center justify-center hover:bg-blue-700 transition-colors"
            >
              Procéder au paiement
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;