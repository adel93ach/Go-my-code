import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Award, Truck, HeartPulse, Clock } from 'lucide-react';
import HeroBanner from '../components/HeroBanner';
import ProductCard from '../components/ProductCard';
import CategoryCard from '../components/CategoryCard';
import { featuredProducts, categories, newProducts } from '../data/products';

const HomePage = () => {
  useEffect(() => {
    // Update page title
    document.title = 'Achaibou Adel Med - Matériel Médical de Qualité';
  }, []);

  return (
    <div>
      <HeroBanner />
      
      {/* Features Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            <div className="p-6 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                <Award className="text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Produits Certifiés</h3>
              <p className="text-gray-600">Tous nos produits répondent aux normes médicales en vigueur.</p>
            </div>
            
            <div className="p-6 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                <Truck className="text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Livraison Rapide</h3>
              <p className="text-gray-600">Livraison en 24-48h sur toute la France métropolitaine.</p>
            </div>
            
            <div className="p-6 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                <HeartPulse className="text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Conseils Personnalisés</h3>
              <p className="text-gray-600">Notre équipe de professionnels est à votre disposition.</p>
            </div>
            
            <div className="p-6 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                <Clock className="text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Service Après-Vente</h3>
              <p className="text-gray-600">Nous assurons un suivi et un service après-vente de qualité.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Categories Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800">Nos Catégories</h2>
            <Link to="/products" className="flex items-center text-blue-600 font-medium mt-4 md:mt-0 hover:text-blue-700 transition-colors">
              Voir tous les produits
              <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map(category => (
              <CategoryCard
                key={category.id}
                id={category.id}
                name={category.name}
                description={category.description}
                image={category.image}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Featured Products Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800">Produits Phares</h2>
            <Link to="/products" className="flex items-center text-blue-600 font-medium mt-4 md:mt-0 hover:text-blue-700 transition-colors">
              Voir tous les produits
              <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredProducts.slice(0, 4).map(product => (
              <ProductCard
                key={product.id}
                product={product}
                featured={true}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* New Products Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800">Nouveaux Produits</h2>
            <Link to="/products" className="flex items-center text-blue-600 font-medium mt-4 md:mt-0 hover:text-blue-700 transition-colors">
              Voir tous les produits
              <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {newProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Testimonial Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-800 text-center mb-10">Ce que nos clients disent</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex text-yellow-400 mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-700 mb-4">
                "Le déambulateur que j'ai acheté est vraiment de très bonne qualité. Il est solide et léger à la fois, ce qui me permet de me déplacer facilement."
              </p>
              <div className="font-semibold text-gray-800">Marie D.</div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex text-yellow-400 mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-700 mb-4">
                "Livraison rapide et service client très réactif. L'oxymètre que j'ai commandé fonctionne parfaitement et est très simple à utiliser."
              </p>
              <div className="font-semibold text-gray-800">Thomas B.</div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex text-yellow-400 mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-700 mb-4">
                "J'ai acheté plusieurs produits et je suis très satisfaite de la qualité. Les prix sont raisonnables et le site est facile à naviguer."
              </p>
              <div className="font-semibold text-gray-800">Sophie M.</div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Besoin d'un conseil personnalisé ?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Notre équipe de professionnels de la santé est à votre disposition pour vous guider dans votre choix.
          </p>
          <Link 
            to="/contact" 
            className="inline-block bg-white text-blue-600 px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
          >
            Contactez-nous
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;