import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';
import Logo from './Logo';

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Logo />
            <p className="text-gray-600 mt-4">
              Votre partenaire pour tous vos besoins médicaux. Qualité et service depuis 2010.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Liens Rapides</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-600 hover:text-blue-600 transition-colors">Accueil</Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-600 hover:text-blue-600 transition-colors">Produits</Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-blue-600 transition-colors">Services</Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-blue-600 transition-colors">Contact</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Catégories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/products?category=orthopedic" className="text-gray-600 hover:text-blue-600 transition-colors">Orthopédie</Link>
              </li>
              <li>
                <Link to="/products?category=mobility" className="text-gray-600 hover:text-blue-600 transition-colors">Mobilité</Link>
              </li>
              <li>
                <Link to="/products?category=medical-equipment" className="text-gray-600 hover:text-blue-600 transition-colors">Équipement Médical</Link>
              </li>
              <li>
                <Link to="/products?category=hygiene" className="text-gray-600 hover:text-blue-600 transition-colors">Hygiène et Soins</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin size={18} className="text-blue-600 mr-2 mt-1 flex-shrink-0" />
                <span className="text-gray-600">123 Rue de la Santé, 75001 Paris, France</span>
              </li>
              <li className="flex items-center">
                <Phone size={18} className="text-blue-600 mr-2 flex-shrink-0" />
                <span className="text-gray-600">+33 1 23 45 67 89</span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="text-blue-600 mr-2 flex-shrink-0" />
                <span className="text-gray-600">contact@achaibou-adel-med.fr</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm">
            &copy; {new Date().getFullYear()} Achaibou Adel Med. Tous droits réservés.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link to="/terms" className="text-gray-600 hover:text-blue-600 text-sm transition-colors">
              Conditions d'utilisation
            </Link>
            <Link to="/privacy" className="text-gray-600 hover:text-blue-600 text-sm transition-colors">
              Politique de confidentialité
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;