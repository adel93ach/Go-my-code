import { Minus, Plus } from 'lucide-react';

interface QuantitySelectorProps {
  quantity: number;
  onIncrease: () => void;
  onDecrease: () => void;
  max?: number;
}

const QuantitySelector = ({ 
  quantity, 
  onIncrease, 
  onDecrease, 
  max = 99 
}: QuantitySelectorProps) => {
  return (
    <div className="flex items-center border border-gray-300 rounded-md overflow-hidden">
      <button
        onClick={onDecrease}
        disabled={quantity <= 1}
        className="p-2 text-gray-600 hover:bg-gray-100 disabled:opacity-50 disabled:hover:bg-white"
        aria-label="Diminuer la quantité"
      >
        <Minus size={16} />
      </button>
      
      <div className="w-12 text-center py-1">
        <span className="text-gray-800">{quantity}</span>
      </div>
      
      <button
        onClick={onIncrease}
        disabled={quantity >= max}
        className="p-2 text-gray-600 hover:bg-gray-100 disabled:opacity-50 disabled:hover:bg-white"
        aria-label="Augmenter la quantité"
      >
        <Plus size={16} />
      </button>
    </div>
  );
};

export default QuantitySelector;