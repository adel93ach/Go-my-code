import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, Heart, ChevronRight, Check, Truck, RotateCcw, Shield } from 'lucide-react';
import QuantitySelector from '../components/QuantitySelector';
import ProductCard from '../components/ProductCard';
import { useCart } from '../context/CartContext';
import { getProductById, products } from '../data/products';

const ProductDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [activeTab, setActiveTab] = useState('description');
  const [relatedProducts, setRelatedProducts] = useState([]);
  
  const product = id ? getProductById(id) : null;
  
  useEffect(() => {
    // Update page title
    if (product) {
      document.title = `${product.name} - MédiPara`;
      
      // Find related products
      const related = products
        .filter(p => p.category === product.category && p.id !== product.id)
        .slice(0, 4);
      
      setRelatedProducts(related);
    }
    
    // Reset state when product changes
    setQuantity(1);
    setActiveImage(0);
    setActiveTab('description');
    
    // Scroll to top
    window.scrollTo(0, 0);
  }, [product, id]);
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Produit non trouvé</h2>
        <p className="text-gray-600 mb-8">
          Le produit que vous recherchez n'existe pas ou a été retiré.
        </p>
        <Link
          to="/products"
          className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-700 transition-colors"
        >
          Voir tous les produits
        </Link>
      </div>
    );
  }

  const handleIncrease = () => {
    setQuantity(prev => Math.min(prev + 1, 10));
  };

  const handleDecrease = () => {
    setQuantity(prev => Math.max(prev - 1, 1));
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <nav className="mb-6">
          <ol className="flex flex-wrap items-center text-sm">
            <li className="text-gray-500">
              <Link to="/" className="hover:text-blue-600 transition-colors">
                Accueil
              </Link>
            </li>
            <ChevronRight size={16} className="mx-2 text-gray-400" />
            <li className="text-gray-500">
              <Link to="/products" className="hover:text-blue-600 transition-colors">
                Produits
              </Link>
            </li>
            <ChevronRight size={16} className="mx-2 text-gray-400" />
            <li className="text-gray-800 font-medium truncate max-w-xs">
              {product.name}
            </li>
          </ol>
        </nav>
        
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
            {/* Product Images */}
            <div>
              <div className="aspect-w-1 aspect-h-1 mb-4">
                <img
                  src={product.images[activeImage]}
                  alt={product.name}
                  className="w-full h-full object-contain rounded-md"
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveImage(index)}
                    className={`border rounded-md overflow-hidden ${
                      index === activeImage ? 'border-blue-600' : 'border-gray-200'
                    }`}
                  >
                    <img src={image} alt={`${product.name} vue ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
            
            {/* Product Info */}
            <div className="flex flex-col">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
                {product.name}
              </h1>
              
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400 mr-2">
                  {[...Array(5)].map((_, i) => (
                    <svg 
                      key={i}
                      className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'fill-current' : 'stroke-current fill-none'}`}
                      viewBox="0 0 24 24"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth="2" 
                        d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                      />
                    </svg>
                  ))}
                </div>
                <span className="text-sm text-gray-600">{product.rating} ({product.reviewCount} avis)</span>
              </div>
              
              <p className="text-gray-600 mb-6">{product.shortDescription}</p>
              
              <div className="mb-6">
                <div className="flex items-center">
                  {product.discountPrice ? (
                    <>
                      <span className="text-3xl font-bold text-gray-800">{product.discountPrice.toFixed(2)}€</span>
                      <span className="text-lg text-gray-500 line-through ml-2">{product.price.toFixed(2)}€</span>
                      <span className="ml-2 bg-red-100 text-red-800 text-xs font-semibold px-2 py-1 rounded-md">
                        -{Math.round(((product.price - product.discountPrice) / product.price) * 100)}%
                      </span>
                    </>
                  ) : (
                    <span className="text-3xl font-bold text-gray-800">{product.price.toFixed(2)}€</span>
                  )}
                </div>
                <p className="text-sm text-gray-500 mt-1">TVA incluse</p>
              </div>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-center">
                  <Check size={18} className={`mr-2 ${product.inStock ? 'text-green-500' : 'text-red-500'}`} />
                  <span className={`${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                    {product.inStock ? 'En stock' : 'Rupture de stock'}
                  </span>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mb-6">
                <QuantitySelector
                  quantity={quantity}
                  onIncrease={handleIncrease}
                  onDecrease={handleDecrease}
                />
                
                <button
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                  className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-md font-medium flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  <ShoppingCart size={20} />
                  <span>Ajouter au panier</span>
                </button>
                
                <button
                  className="w-12 h-12 rounded-md border border-gray-200 flex items-center justify-center text-gray-600 hover:bg-gray-50 transition-colors"
                  aria-label="Ajouter aux favoris"
                >
                  <Heart size={20} />
                </button>
              </div>
              
              <div className="border-t border-gray-200 pt-6 space-y-4">
                <div className="flex items-start">
                  <Truck size={20} className="text-blue-600 mt-1 mr-3 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-gray-800">Livraison rapide</p>
                    <p className="text-sm text-gray-600">Livraison en 24-48h sur toute la France métropolitaine</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <RotateCcw size={20} className="text-blue-600 mt-1 mr-3 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-gray-800">Retours gratuits sous 30 jours</p>
                    <p className="text-sm text-gray-600">Si vous n'êtes pas satisfait, nous vous remboursons</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Shield size={20} className="text-blue-600 mt-1 mr-3 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-gray-800">Garantie qualité</p>
                    <p className="text-sm text-gray-600">Tous nos produits sont certifiés aux normes médicales européennes</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="border-t border-gray-200">
            <div className="flex overflow-x-auto">
              <button
                onClick={() => setActiveTab('description')}
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap ${
                  activeTab === 'description'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Description
              </button>
              <button
                onClick={() => setActiveTab('features')}
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap ${
                  activeTab === 'features'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Caractéristiques
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap ${
                  activeTab === 'reviews'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Avis clients ({product.reviewCount})
              </button>
            </div>
            
            <div className="p-6">
              {activeTab === 'description' && (
                <div className="prose max-w-none">
                  <p className="text-gray-700 leading-relaxed">{product.description}</p>
                </div>
              )}
              
              {activeTab === 'features' && (
                <div className="prose max-w-none">
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check size={20} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {activeTab === 'reviews' && (
                <div>
                  <div className="flex items-center mb-6">
                    <div className="flex items-center">
                      <span className="text-3xl font-bold text-gray-800 mr-2">{product.rating}</span>
                      <div className="flex text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <svg 
                            key={i}
                            className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'fill-current' : 'stroke-current fill-none'}`}
                            viewBox="0 0 24 24"
                          >
                            <path 
                              strokeLinecap="round" 
                              strokeLinejoin="round" 
                              strokeWidth="2" 
                              d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                            />
                          </svg>
                        ))}
                      </div>
                    </div>
                    <span className="text-gray-600 ml-2">Basé sur {product.reviewCount} avis</span>
                  </div>
                  
                  <p className="text-gray-600 mb-4">
                    Les avis clients détaillés seront bientôt disponibles.
                  </p>
                  
                  <button className="bg-blue-600 text-white py-2 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors">
                    Écrire un avis
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Produits associés</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {relatedProducts.map(relatedProduct => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;