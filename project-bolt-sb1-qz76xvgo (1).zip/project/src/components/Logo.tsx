import { Stethoscope } from 'lucide-react';

const Logo = () => {
  return (
    <div className="flex items-center">
      <Stethoscope className="h-8 w-8 text-blue-600 mr-2" />
      <span className="text-xl font-bold text-gray-800">Achaibou Adel Med</span>
    </div>
  );
};

export default Logo;